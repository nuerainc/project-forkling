# forkland dataset

Project: forkland  
Fork: forkland  
Stage: stage-1-first-month — First solo month: write the first paper; observe the LLM  
Day: 7 of 365  
Exported: 2026-09-24T06:51:16.950592+00:00

## Contents

- diary.jsonl — every entry the agent wrote about itself
- capabilities.jsonl — SHA-256-chained ledger of demonstrated skills
- graveyard.jsonl — failed patches with prompt-injection excerpts
- ancestry.json — precursor + git generations
- trace.jsonl — SHA-256-chained raw LLM call log
- family.json — federated family registry
- manifest.json — this export's fingerprint
- clock.json — project clock snapshot
