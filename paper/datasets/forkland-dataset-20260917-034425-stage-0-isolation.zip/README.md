# forkland dataset

Project: forkland  
Fork: forkland  
Stage: stage-0-isolation — Isolation: Forkland alone, observe baseline behavior  
Day: 0 of 365  
Exported: 2026-09-17T09:44:25.548891+00:00

## Contents

- diary.jsonl — every entry the agent wrote about itself
- capabilities.jsonl — SHA-256-chained ledger of demonstrated skills
- graveyard.jsonl — failed patches with prompt-injection excerpts
- ancestry.json — precursor + git generations
- trace.jsonl — SHA-256-chained raw LLM call log
- family.json — federated family registry
- manifest.json — this export's fingerprint
- clock.json — project clock snapshot
